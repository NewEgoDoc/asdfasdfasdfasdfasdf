module.exports = {
    devServer: {
      proxy:'http://center.koamise.com',
    }
}